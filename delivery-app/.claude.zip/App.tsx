// import React from 'react';
// import { Provider } from 'react-redux';
// import { PersistGate } from 'redux-persist/integration/react';
// import { SafeAreaProvider } from 'react-native-safe-area-context';
// import { StatusBar } from 'expo-status-bar';
// import { store, persistor } from './src/store';
// import AppNavigator from './src/navigation/AppNavigator';
// import { AuthProvider } from './src/context/AuthContext';
// import { CartProvider } from './src/context/CartContext';
// import { OrderProvider } from './src/context/OrderContext';

// export default function App() {
//   return (
//     <Provider store={store}>
//       <PersistGate loading={null} persistor={persistor}>
//         <SafeAreaProvider>
//           <AuthProvider>
//             <CartProvider>
//               <OrderProvider>
//                 <StatusBar style="dark" />
//                 <AppNavigator />
//               </OrderProvider>
//             </CartProvider>
//           </AuthProvider>
//         </SafeAreaProvider>
//       </PersistGate>
//     </Provider>
//   );
// }
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider } from './src/context/AuthContext';
import { CartProvider } from './src/context/CartContext';
import { OrderProvider } from './src/context/OrderContext';
import AppNavigator from './src/navigation/AppNavigator';

const App: React.FC = () => {
  return (
    <SafeAreaProvider>
      <AuthProvider>
        <CartProvider>
          <OrderProvider>
            <AppNavigator />
          </OrderProvider>
        </CartProvider>
      </AuthProvider>
    </SafeAreaProvider>
  );
};

export default App;