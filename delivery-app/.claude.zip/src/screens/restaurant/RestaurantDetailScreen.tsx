// import React, { useState, useContext } from 'react';
// import {
//   View,
//   Text,
//   ScrollView,
//   TouchableOpacity,
//   StyleSheet,
//   Image,
//   FlatList,
//   Alert,
// } from 'react-native';
// import Icon from 'react-native-vector-icons/Ionicons';
// import { colors } from '../../constants/colors';
// import { CartContext } from '../../context/CartContext';
// import { menuItems } from '../../constants/dummyData';
// import { Restaurant, MenuItem } from '../../types';

// export default function RestaurantDetailScreen({ route, navigation }: any) {
//   const { restaurant } = route.params || {};
//   const { addToCart } = useContext(CartContext);
//   const [selectedCategory, setSelectedCategory] = useState<string>('Recommended');

//   const categories: string[] = ['Recommended', 'Swiggy Special', 'Quick Bites', 'Soups', 'Starters', 'Main Course'];

//   const restaurantData: Restaurant = restaurant || {
//     id: '1',
//     name: 'Gourmand\'s Delight',
//     rating: 4.2,
//     deliveryTime: '27 mins',
//     cuisine: 'North Indian, Chinese',
//     image: 'https://via.placeholder.com/150',
//     costForTwo: '₹700 for two',
//     address: 'Sector 1, HSR Layout',
//     isVeg: false,
//   };

//   const menu: MenuItem[] = menuItems || [
//     {
//       id: '1',
//       name: 'Green Peas Masala',
//       price: 135,
//       rating: 4.0,
//       reviews: 100,
//       isBestSeller: false,
//       description: 'Green peas in rich gravy',
//       image: 'https://via.placeholder.com/150',
//       isVeg: true,
//       category: 'Main Course',
//     },
//     {
//       id: '2',
//       name: 'Paneer Butter Masala',
//       price: 166,
//       rating: 4.5,
//       reviews: 200,
//       isBestSeller: true,
//       description: 'Creamy paneer in rich tomato gravy',
//       image: 'https://via.placeholder.com/150',
//       isVeg: true,
//       category: 'Main Course',
//     },
//   ];

//   const handleAddToCart = (item: MenuItem): void => {
//     const cartItem = {
//       id: item.id,
//       name: item.name,
//       price: item.price,
//       quantity: 1,
//       image: item.image,
//       restaurantId: restaurantData.id,
//       restaurantName: restaurantData.name,
//     };
//     addToCart(cartItem, restaurantData);
//     Alert.alert('Added to Cart', `${item.name} added to your cart`);
//   };

//   const renderMenuItem = ({ item }: { item: MenuItem }) => (
//     <View style={styles.menuItem}>
//       <View style={styles.menuItemContent}>
//         <View style={styles.menuItemInfo}>
//           <Text style={styles.menuItemName}>{item.name}</Text>
//           <Text style={styles.menuItemPrice}>₹{item.price}</Text>
//           <View style={styles.menuItemRating}>
//             <Icon name="star" size={14} color="#ffc107" />
//             <Text style={styles.ratingText}>{item.rating || 4.0}</Text>
//             {item.isBestSeller && (
//               <View style={styles.bestsellerBadge}>
//                 <Text style={styles.bestsellerText}>BESTSELLER</Text>
//               </View>
//             )}
//           </View>
//           {item.description && (
//             <Text style={styles.menuItemDescription} numberOfLines={2}>
//               {item.description}
//             </Text>
//           )}
//         </View>
//         <TouchableOpacity
//           style={styles.addButton}
//           onPress={() => handleAddToCart(item)}
//         >
//           <Text style={styles.addButtonText}>ADD</Text>
//         </TouchableOpacity>
//       </View>
//       <View style={styles.divider} />
//     </View>
//   );

//   const renderCategory = ({ item }: { item: string }) => (
//     <TouchableOpacity
//       style={[styles.categoryTab, selectedCategory === item && styles.activeCategoryTab]}
//       onPress={() => setSelectedCategory(item)}
//     >
//       <Text style={[styles.categoryTabText, selectedCategory === item && styles.activeCategoryTabText]}>
//         {item}
//       </Text>
//     </TouchableOpacity>
//   );

//   return (
//     <View style={styles.container}>
//       <ScrollView showsVerticalScrollIndicator={false}>
//         {/* Header Image */}
//         <View style={styles.imageContainer}>
//           <Image
//             source={{ uri: restaurantData.image || 'https://via.placeholder.com/400x200' }}
//             style={styles.restaurantImage}
//           />
//           <TouchableOpacity
//             style={styles.backButton}
//             onPress={() => navigation.goBack()}
//           >
//             <Icon name="arrow-back" size={24} color={colors.white} />
//           </TouchableOpacity>
//           <TouchableOpacity style={styles.favoriteButton}>
//             <Icon name="heart-outline" size={24} color={colors.white} />
//           </TouchableOpacity>
//         </View>

//         {/* Restaurant Info */}
//         <View style={styles.infoContainer}>
//           <Text style={styles.restaurantName}>{restaurantData.name}</Text>
//           <View style={styles.ratingContainer}>
//             <View style={styles.ratingBadge}>
//               <Icon name="star" size={14} color={colors.white} />
//               <Text style={styles.ratingText}>{restaurantData.rating || 4.2}</Text>
//             </View>
//             <Text style={styles.deliveryTime}>{restaurantData.deliveryTime || '27 mins'}</Text>
//             <Text style={styles.costForTwo}>{restaurantData.costForTwo || '₹700 for two'}</Text>
//           </View>
//           <Text style={styles.cuisine}>{restaurantData.cuisine || 'North Indian, Chinese'}</Text>
//         </View>

//         {/* Category Tabs */}
//         <View style={styles.categoriesContainer}>
//           <FlatList
//             data={categories}
//             renderItem={renderCategory}
//             keyExtractor={(item) => item}
//             horizontal
//             showsHorizontalScrollIndicator={false}
//             contentContainerStyle={styles.categoriesList}
//           />
//         </View>

//         {/* Menu Items */}
//         <View style={styles.menuContainer}>
//           <Text style={styles.menuTitle}>{selectedCategory}</Text>
//           <FlatList
//             data={menu}
//             renderItem={renderMenuItem}
//             keyExtractor={(item) => item.id}
//             scrollEnabled={false}
//           />
//         </View>
//       </ScrollView>
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: colors.white,
//   },
//   imageContainer: {
//     position: 'relative',
//     height: 220,
//   },
//   restaurantImage: {
//     width: '100%',
//     height: '100%',
//   },
//   backButton: {
//     position: 'absolute',
//     top: 40,
//     left: 16,
//     backgroundColor: 'rgba(0,0,0,0.5)',
//     borderRadius: 20,
//     padding: 8,
//   },
//   favoriteButton: {
//     position: 'absolute',
//     top: 40,
//     right: 16,
//     backgroundColor: 'rgba(0,0,0,0.5)',
//     borderRadius: 20,
//     padding: 8,
//   },
//   infoContainer: {
//     padding: 16,
//   },
//   restaurantName: {
//     fontSize: 22,
//     fontWeight: '700',
//     color: colors.text,
//   },
//   ratingContainer: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     marginTop: 8,
//   },
//   ratingBadge: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     backgroundColor: colors.success,
//     paddingHorizontal: 8,
//     paddingVertical: 2,
//     borderRadius: 4,
//   },
//   ratingText: {
//     color: colors.white,
//     fontSize: 12,
//     fontWeight: '600',
//     marginLeft: 4,
//   },
//   deliveryTime: {
//     fontSize: 13,
//     color: colors.textLight,
//     marginLeft: 12,
//   },
//   costForTwo: {
//     fontSize: 13,
//     color: colors.textLight,
//     marginLeft: 12,
//   },
//   cuisine: {
//     fontSize: 14,
//     color: colors.textLight,
//     marginTop: 6,
//   },
//   categoriesContainer: {
//     borderTopWidth: 1,
//     borderBottomWidth: 1,
//     borderColor: colors.border,
//     paddingVertical: 8,
//   },
//   categoriesList: {
//     paddingHorizontal: 16,
//   },
//   categoryTab: {
//     paddingHorizontal: 16,
//     paddingVertical: 8,
//     marginRight: 8,
//     borderRadius: 20,
//     backgroundColor: colors.lightGray,
//   },
//   activeCategoryTab: {
//     backgroundColor: colors.primary,
//   },
//   categoryTabText: {
//     fontSize: 13,
//     color: colors.text,
//   },
//   activeCategoryTabText: {
//     color: colors.white,
//   },
//   menuContainer: {
//     padding: 16,
//     paddingBottom: 80,
//   },
//   menuTitle: {
//     fontSize: 18,
//     fontWeight: '600',
//     color: colors.text,
//     marginBottom: 12,
//   },
//   menuItem: {
//     marginBottom: 4,
//   },
//   menuItemContent: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     paddingVertical: 12,
//   },
//   menuItemInfo: {
//     flex: 1,
//     marginRight: 12,
//   },
//   menuItemName: {
//     fontSize: 16,
//     fontWeight: '500',
//     color: colors.text,
//   },
//   menuItemPrice: {
//     fontSize: 14,
//     color: colors.text,
//     marginTop: 4,
//   },
//   menuItemRating: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     marginTop: 4,
//   },
//   bestsellerBadge: {
//     backgroundColor: '#fff8e1',
//     paddingHorizontal: 8,
//     paddingVertical: 2,
//     borderRadius: 4,
//     marginLeft: 8,
//   },
//   bestsellerText: {
//     fontSize: 10,
//     color: '#ff6f00',
//     fontWeight: '600',
//   },
//   menuItemDescription: {
//     fontSize: 12,
//     color: colors.textLight,
//     marginTop: 4,
//   },
//   addButton: {
//     borderWidth: 1,
//     borderColor: colors.primary,
//     paddingHorizontal: 16,
//     paddingVertical: 6,
//     borderRadius: 6,
//   },
//   addButtonText: {
//     color: colors.primary,
//     fontSize: 12,
//     fontWeight: '600',
//   },
//   divider: {
//     height: 1,
//     backgroundColor: colors.border,
//   },
// });
import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Image,
  FlatList,
  Alert,
  SafeAreaView,
  StatusBar,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { colors } from '../../constants/colors';
import { CartContext } from '../../context/CartContext';

// Menu items data organized by category
const MENU_DATA = {
  'Recommended': [
    {
      id: 1,
      name: 'Korean BBQ Chicken Burger',
      price: 330,
      rating: 4.5,
      reviews: 5000,
      description: 'Fried chicken, Asian coleslaw with sweet-spicy Korean BBQ glaze',
      image: 'https://via.placeholder.com/150',
      isBestSeller: true,
      isVeg: false,
      category: 'Burgers',
    },
    {
      id: 2,
      name: 'Paneer Butter Masala',
      price: 185,
      rating: 4.2,
      reviews: 1000,
      description: 'Creamy paneer in rich tomato gravy',
      image: 'https://via.placeholder.com/150',
      isBestSeller: true,
      isVeg: true,
      category: 'Main Course',
    },
    {
      id: 3,
      name: 'Margherita Pizza',
      price: 369,
      rating: 4.3,
      reviews: 2500,
      description: 'Classic cheese pizza with tomato sauce',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: true,
      category: 'Pizzas',
    },
  ],
  'Swiggy Special': [
    {
      id: 4,
      name: 'Special Biryani Combo',
      price: 499,
      rating: 4.8,
      reviews: 3000,
      description: 'Hyderabadi biryani with raita and salan',
      image: 'https://via.placeholder.com/150',
      isBestSeller: true,
      isVeg: false,
      category: 'Biryani',
    },
    {
      id: 5,
      name: 'Butter Chicken Feast',
      price: 599,
      rating: 4.7,
      reviews: 2000,
      description: 'Creamy butter chicken with naan and rice',
      image: 'https://via.placeholder.com/150',
      isBestSeller: true,
      isVeg: false,
      category: 'Main Course',
    },
    {
      id: 6,
      name: 'Veg Thali Special',
      price: 349,
      rating: 4.6,
      reviews: 1500,
      description: 'Complete veg thali with dal, sabzi, roti, rice and dessert',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: true,
      category: 'Thali',
    },
    {
      id: 7,
      name: 'Chicken Lollipop',
      price: 299,
      rating: 4.5,
      reviews: 1800,
      description: 'Crispy fried chicken lollipop with schezwan sauce',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: false,
      category: 'Starters',
    },
  ],
  'Quick Bites': [
    {
      id: 8,
      name: 'Veg Burger',
      price: 149,
      rating: 4.0,
      reviews: 800,
      description: 'Grilled veg patty with lettuce and mayo',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: true,
      category: 'Burgers',
    },
    {
      id: 9,
      name: 'Chicken Wrap',
      price: 199,
      rating: 4.1,
      reviews: 900,
      description: 'Grilled chicken wrap with veggies and sauce',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: false,
      category: 'Wraps',
    },
    {
      id: 10,
      name: 'French Fries',
      price: 99,
      rating: 4.2,
      reviews: 1200,
      description: 'Crispy golden fries with ketchup',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: true,
      category: 'Snacks',
    },
    {
      id: 11,
      name: 'Paneer Tikka',
      price: 249,
      rating: 4.3,
      reviews: 700,
      description: 'Grilled paneer with bell peppers and onions',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: true,
      category: 'Starters',
    },
  ],
  'Soups': [
    {
      id: 12,
      name: 'Tomato Soup',
      price: 129,
      rating: 4.0,
      reviews: 500,
      description: 'Creamy tomato soup with croutons',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: true,
      category: 'Soups',
    },
    {
      id: 13,
      name: 'Chicken Noodle Soup',
      price: 179,
      rating: 4.2,
      reviews: 600,
      description: 'Clear chicken soup with noodles and vegetables',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: false,
      category: 'Soups',
    },
    {
      id: 14,
      name: 'Sweet Corn Soup',
      price: 149,
      rating: 4.1,
      reviews: 450,
      description: 'Creamy sweet corn soup with vegetables',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: true,
      category: 'Soups',
    },
    {
      id: 15,
      name: 'Hot & Sour Soup',
      price: 169,
      rating: 4.3,
      reviews: 550,
      description: 'Spicy and sour soup with vegetables',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: true,
      category: 'Soups',
    },
  ],
  'Starters': [
    {
      id: 16,
      name: 'Chicken 65',
      price: 299,
      rating: 4.4,
      reviews: 800,
      description: 'Spicy fried chicken with curry leaves',
      image: 'https://via.placeholder.com/150',
      isBestSeller: true,
      isVeg: false,
      category: 'Starters',
    },
    {
      id: 17,
      name: 'Paneer Tikka',
      price: 249,
      rating: 4.3,
      reviews: 700,
      description: 'Grilled paneer with bell peppers',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: true,
      category: 'Starters',
    },
    {
      id: 18,
      name: 'Gobi Manchurian',
      price: 219,
      rating: 4.2,
      reviews: 600,
      description: 'Crispy cauliflower in manchurian sauce',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: true,
      category: 'Starters',
    },
    {
      id: 19,
      name: 'Spring Rolls',
      price: 189,
      rating: 4.0,
      reviews: 500,
      description: 'Crispy vegetable spring rolls with sweet chilli sauce',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: true,
      category: 'Starters',
    },
  ],
  'Main Course': [
    {
      id: 20,
      name: 'Butter Chicken',
      price: 399,
      rating: 4.6,
      reviews: 1200,
      description: 'Tender chicken in creamy tomato gravy',
      image: 'https://via.placeholder.com/150',
      isBestSeller: true,
      isVeg: false,
      category: 'Main Course',
    },
    {
      id: 21,
      name: 'Dal Makhani',
      price: 299,
      rating: 4.4,
      reviews: 900,
      description: 'Slow cooked black dal with butter and cream',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: true,
      category: 'Main Course',
    },
    {
      id: 22,
      name: 'Paneer Butter Masala',
      price: 329,
      rating: 4.5,
      reviews: 1000,
      description: 'Creamy paneer in rich tomato gravy',
      image: 'https://via.placeholder.com/150',
      isBestSeller: true,
      isVeg: true,
      category: 'Main Course',
    },
    {
      id: 23,
      name: 'Chicken Biryani',
      price: 449,
      rating: 4.7,
      reviews: 1500,
      description: 'Fragrant basmati rice with spicy chicken',
      image: 'https://via.placeholder.com/150',
      isBestSeller: true,
      isVeg: false,
      category: 'Main Course',
    },
    {
      id: 24,
      name: 'Veg Biryani',
      price: 369,
      rating: 4.3,
      reviews: 800,
      description: 'Fragrant basmati rice with mixed vegetables',
      image: 'https://via.placeholder.com/150',
      isBestSeller: false,
      isVeg: true,
      category: 'Main Course',
    },
  ],
};

interface RestaurantDetailScreenProps {
  route: any;
  navigation: any;
}

const RestaurantDetailScreen: React.FC<RestaurantDetailScreenProps> = ({ route, navigation }) => {
  const { restaurant } = route.params || {};
  const { addToCart } = useContext(CartContext);
  const [selectedCategory, setSelectedCategory] = useState<string>('Recommended');

  const categories = ['Recommended', 'Swiggy Special', 'Quick Bites', 'Soups', 'Starters', 'Main Course'];

  const restaurantData = restaurant || {
    id: 1,
    name: 'Gourmand\'s Delight',
    rating: 4.2,
    deliveryTime: '27 mins',
    cuisine: 'North Indian, Chinese',
    image: 'https://via.placeholder.com/150',
    costForTwo: '₹700 for two',
    address: 'Sector 1, HSR Layout',
    isVeg: false,
  };

  // Get menu items for selected category
  const getMenuItems = () => {
    return MENU_DATA[selectedCategory as keyof typeof MENU_DATA] || [];
  };

  const handleAddToCart = (item: any) => {
    const cartItem = {
      id: item.id,
      name: item.name,
      price: item.price,
      quantity: 1,
      image: item.image,
      restaurantId: restaurantData.id,
      restaurantName: restaurantData.name,
    };
    addToCart(cartItem, restaurantData);
    Alert.alert('Added to Cart', `${item.name} added to your cart`);
  };

  const renderCategoryTab = ({ item }: { item: string }) => (
    <TouchableOpacity
      style={[
        styles.categoryTab,
        selectedCategory === item && styles.activeCategoryTab,
      ]}
      onPress={() => setSelectedCategory(item)}
    >
      <Text
        style={[
          styles.categoryTabText,
          selectedCategory === item && styles.activeCategoryTabText,
        ]}
      >
        {item}
      </Text>
      {selectedCategory === item && <View style={styles.activeIndicator} />}
    </TouchableOpacity>
  );

  const renderMenuItem = ({ item }: { item: any }) => (
    <View style={styles.menuItem}>
      <View style={styles.menuItemContent}>
        <View style={styles.menuItemInfo}>
          <View style={styles.menuItemHeader}>
            <Text style={styles.menuItemName}>{item.name}</Text>
            {item.isBestSeller && (
              <View style={styles.bestsellerBadge}>
                <Icon name="star" size={12} color="#ff6f00" />
                <Text style={styles.bestsellerText}>BESTSELLER</Text>
              </View>
            )}
          </View>
          <Text style={styles.menuItemPrice}>₹{item.price}</Text>
          <View style={styles.menuItemRating}>
            <Icon name="star" size={14} color="#ffc107" />
            <Text style={styles.ratingText}>{item.rating}</Text>
            <Text style={styles.reviewsText}>({item.reviews}+ reviews)</Text>
          </View>
          {item.description && (
            <Text style={styles.menuItemDescription} numberOfLines={2}>
              {item.description}
            </Text>
          )}
        </View>
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => handleAddToCart(item)}
        >
          <Text style={styles.addButtonText}>ADD</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.divider} />
    </View>
  );

  const menuItems = getMenuItems();

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
      
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header Image */}
        <View style={styles.imageContainer}>
          <Image
            source={{ uri: restaurantData.image || 'https://via.placeholder.com/400x200' }}
            style={styles.restaurantImage}
          />
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <Icon name="arrow-back" size={24} color="#ffffff" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.favoriteButton}>
            <Icon name="heart-outline" size={24} color="#ffffff" />
          </TouchableOpacity>
        </View>

        {/* Restaurant Info */}
        <View style={styles.infoContainer}>
          <Text style={styles.restaurantName}>{restaurantData.name}</Text>
          <View style={styles.ratingContainer}>
            <View style={styles.ratingBadge}>
              <Icon name="star" size={14} color="#ffffff" />
              <Text style={styles.ratingBadgeText}>{restaurantData.rating || 4.2}</Text>
            </View>
            <Text style={styles.deliveryTime}>{restaurantData.deliveryTime || '27 mins'}</Text>
            <Text style={styles.costForTwo}>{restaurantData.costForTwo || '₹700 for two'}</Text>
          </View>
          <Text style={styles.cuisine}>{restaurantData.cuisine || 'North Indian, Chinese'}</Text>
        </View>

        {/* Category Tabs */}
        <View style={styles.categoriesContainer}>
          <FlatList
            data={categories}
            renderItem={renderCategoryTab}
            keyExtractor={(item) => item}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.categoriesList}
          />
        </View>

        {/* Menu Items */}
        <View style={styles.menuContainer}>
          <View style={styles.menuHeader}>
            <Text style={styles.menuTitle}>{selectedCategory}</Text>
            <Text style={styles.menuCount}>{menuItems.length} items</Text>
          </View>
          
          {menuItems.length > 0 ? (
            <FlatList
              data={menuItems}
              renderItem={renderMenuItem}
              keyExtractor={(item) => item.id.toString()}
              scrollEnabled={false}
            />
          ) : (
            <View style={styles.emptyContainer}>
              <Icon name="restaurant-outline" size={60} color="#ccc" />
              <Text style={styles.emptyText}>No items in this category</Text>
            </View>
          )}
        </View>

        {/* Footer Spacing */}
        <View style={styles.footerSpacing} />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  imageContainer: {
    position: 'relative',
    height: 220,
  },
  restaurantImage: {
    width: '100%',
    height: '100%',
  },
  backButton: {
    position: 'absolute',
    top: 12,
    left: 16,
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: 20,
    padding: 8,
  },
  favoriteButton: {
    position: 'absolute',
    top: 12,
    right: 16,
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: 20,
    padding: 8,
  },
  infoContainer: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f5',
  },
  restaurantName: {
    fontSize: 22,
    fontWeight: '700',
    color: '#282c3f',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#28a745',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
  },
  ratingBadgeText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
  deliveryTime: {
    fontSize: 13,
    color: '#7e808c',
    marginLeft: 12,
  },
  costForTwo: {
    fontSize: 13,
    color: '#7e808c',
    marginLeft: 12,
  },
  cuisine: {
    fontSize: 14,
    color: '#7e808c',
    marginTop: 6,
  },
  categoriesContainer: {
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f5',
    backgroundColor: '#ffffff',
  },
  categoriesList: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  categoryTab: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginRight: 4,
    position: 'relative',
  },
  activeCategoryTab: {
    // Active styles handled by indicator
  },
  categoryTabText: {
    fontSize: 14,
    color: '#7e808c',
    fontWeight: '500',
  },
  activeCategoryTabText: {
    color: '#fc8019',
    fontWeight: '600',
  },
  activeIndicator: {
    position: 'absolute',
    bottom: 0,
    left: 16,
    right: 16,
    height: 3,
    backgroundColor: '#fc8019',
    borderRadius: 2,
  },
  menuContainer: {
    padding: 16,
  },
  menuHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  menuTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#282c3f',
  },
  menuCount: {
    fontSize: 13,
    color: '#7e808c',
  },
  menuItem: {
    marginBottom: 4,
  },
  menuItemContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  menuItemInfo: {
    flex: 1,
    marginRight: 12,
  },
  menuItemHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  menuItemName: {
    fontSize: 16,
    fontWeight: '500',
    color: '#282c3f',
  },
  bestsellerBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff8e1',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
    marginLeft: 8,
  },
  bestsellerText: {
    fontSize: 10,
    color: '#ff6f00',
    fontWeight: '600',
    marginLeft: 4,
  },
  menuItemPrice: {
    fontSize: 15,
    fontWeight: '600',
    color: '#282c3f',
    marginTop: 4,
  },
  menuItemRating: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  ratingText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#282c3f',
    marginLeft: 4,
  },
  reviewsText: {
    fontSize: 12,
    color: '#7e808c',
    marginLeft: 4,
  },
  menuItemDescription: {
    fontSize: 12,
    color: '#7e808c',
    marginTop: 4,
    lineHeight: 16,
  },
  addButton: {
    borderWidth: 1,
    borderColor: '#fc8019',
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 6,
    backgroundColor: '#ffffff',
  },
  addButtonText: {
    color: '#fc8019',
    fontSize: 12,
    fontWeight: '600',
  },
  divider: {
    height: 1,
    backgroundColor: '#f0f0f5',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 16,
    color: '#7e808c',
    marginTop: 12,
  },
  footerSpacing: {
    height: 80,
  },
});

export default RestaurantDetailScreen;