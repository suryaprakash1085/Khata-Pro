// import React, { useState } from 'react';
// import {
//   View,
//   Text,
//   TextInput,
//   FlatList,
//   TouchableOpacity,
//   StyleSheet,
//   Image,
// } from 'react-native';
// import Icon from 'react-native-vector-icons/Ionicons';
// import { colors } from '../../constants/colors';
// import { restaurants, categories } from '../../constants/dummyData';
// import { Restaurant, Category } from '../../types';

// export default function SearchScreen({ navigation }: any) {
//   const [searchText, setSearchText] = useState<string>('');
//   const [searchResults, setSearchResults] = useState<Restaurant[]>([]);

//   const handleSearch = (text: string): void => {
//     setSearchText(text);
//     if (text.trim()) {
//       const results = restaurants.filter(
//         (item: Restaurant) =>
//           item.name.toLowerCase().includes(text.toLowerCase()) ||
//           item.cuisine.toLowerCase().includes(text.toLowerCase())
//       );
//       setSearchResults(results);
//     } else {
//       setSearchResults([]);
//     }
//   };

//   const renderCategory = ({ item }: { item: Category }) => (
//     <TouchableOpacity style={styles.categoryChip}>
//       <Text style={styles.categoryChipText}>{item.icon} {item.name}</Text>
//     </TouchableOpacity>
//   );

//   const renderResult = ({ item }: { item: Restaurant }) => (
//     <TouchableOpacity
//       style={styles.resultItem}
//       onPress={() => navigation.navigate('RestaurantDetail', { restaurant: item })}
//     >
//       <Image source={{ uri: item.image }} style={styles.resultImage} />
//       <View style={styles.resultInfo}>
//         <Text style={styles.resultName}>{item.name}</Text>
//         <Text style={styles.resultCuisine}>{item.cuisine}</Text>
//         <View style={styles.resultMeta}>
//           <Text style={styles.resultRating}>⭐ {item.rating}</Text>
//           <Text style={styles.resultTime}>• {item.deliveryTime}</Text>
//         </View>
//       </View>
//     </TouchableOpacity>
//   );

//   return (
//     <View style={styles.container}>
//       {/* Search Header */}
//       <View style={styles.header}>
//         <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
//           <Icon name="arrow-back" size={24} color={colors.text} />
//         </TouchableOpacity>
//         <View style={styles.searchContainer}>
//           <Icon name="search" size={20} color={colors.gray} style={styles.searchIcon} />
//           <TextInput
//             style={styles.searchInput}
//             placeholder="Search for restaurant, item or more"
//             value={searchText}
//             onChangeText={handleSearch}
//             autoFocus
//           />
//           {searchText.length > 0 && (
//             <TouchableOpacity onPress={() => handleSearch('')}>
//               <Icon name="close-circle" size={20} color={colors.gray} />
//             </TouchableOpacity>
//           )}
//         </View>
//       </View>

//       {searchText.length === 0 ? (
//         <>
//           {/* Popular Categories */}
//           <View style={styles.categoriesSection}>
//             <Text style={styles.sectionTitle}>Popular Categories</Text>
//             <FlatList
//               data={categories.slice(0, 8)}
//               renderItem={renderCategory}
//               keyExtractor={(item) => item.id}
//               horizontal
//               showsHorizontalScrollIndicator={false}
//               contentContainerStyle={styles.categoriesList}
//             />
//           </View>

//           {/* Recent Searches */}
//           <View style={styles.recentSection}>
//             <Text style={styles.sectionTitle}>Recent Searches</Text>
//             <View style={styles.recentItem}>
//               <Icon name="time-outline" size={20} color={colors.gray} />
//               <Text style={styles.recentText}>Pizza Hut</Text>
//             </View>
//             <View style={styles.recentItem}>
//               <Icon name="time-outline" size={20} color={colors.gray} />
//               <Text style={styles.recentText}>Biryani</Text>
//             </View>
//           </View>
//         </>
//       ) : (
//         <FlatList
//           data={searchResults}
//           renderItem={renderResult}
//           keyExtractor={(item) => item.id}
//           contentContainerStyle={styles.resultsList}
//           ListEmptyComponent={
//             <View style={styles.emptyContainer}>
//               <Icon name="search-outline" size={60} color={colors.gray} />
//               <Text style={styles.emptyText}>No results found</Text>
//               <Text style={styles.emptySubText}>Try searching for something else</Text>
//             </View>
//           }
//         />
//       )}
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: colors.white,
//   },
//   header: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     padding: 16,
//     borderBottomWidth: 1,
//     borderBottomColor: colors.border,
//   },
//   backButton: {
//     marginRight: 12,
//   },
//   searchContainer: {
//     flex: 1,
//     flexDirection: 'row',
//     alignItems: 'center',
//     backgroundColor: colors.lightGray,
//     borderRadius: 12,
//     paddingHorizontal: 12,
//     height: 44,
//   },
//   searchIcon: {
//     marginRight: 8,
//   },
//   searchInput: {
//     flex: 1,
//     fontSize: 14,
//     color: colors.text,
//   },
//   categoriesSection: {
//     padding: 16,
//   },
//   sectionTitle: {
//     fontSize: 16,
//     fontWeight: '600',
//     color: colors.text,
//     marginBottom: 12,
//   },
//   categoriesList: {
//     paddingVertical: 4,
//   },
//   categoryChip: {
//     backgroundColor: colors.lightGray,
//     paddingHorizontal: 16,
//     paddingVertical: 8,
//     borderRadius: 20,
//     marginRight: 10,
//   },
//   categoryChipText: {
//     fontSize: 14,
//     color: colors.text,
//   },
//   recentSection: {
//     paddingHorizontal: 16,
//   },
//   recentItem: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     paddingVertical: 12,
//     borderBottomWidth: 1,
//     borderBottomColor: colors.border,
//   },
//   recentText: {
//     fontSize: 14,
//     color: colors.text,
//     marginLeft: 12,
//   },
//   resultsList: {
//     padding: 16,
//   },
//   resultItem: {
//     flexDirection: 'row',
//     marginBottom: 16,
//     backgroundColor: colors.white,
//     borderRadius: 12,
//     borderWidth: 1,
//     borderColor: colors.border,
//     padding: 8,
//   },
//   resultImage: {
//     width: 80,
//     height: 80,
//     borderRadius: 8,
//   },
//   resultInfo: {
//     flex: 1,
//     marginLeft: 12,
//     justifyContent: 'center',
//   },
//   resultName: {
//     fontSize: 16,
//     fontWeight: '600',
//     color: colors.text,
//   },
//   resultCuisine: {
//     fontSize: 13,
//     color: colors.textLight,
//     marginTop: 2,
//   },
//   resultMeta: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     marginTop: 4,
//   },
//   resultRating: {
//     fontSize: 12,
//     color: colors.text,
//   },
//   resultTime: {
//     fontSize: 12,
//     color: colors.textLight,
//     marginLeft: 4,
//   },
//   emptyContainer: {
//     alignItems: 'center',
//     justifyContent: 'center',
//     paddingVertical: 60,
//   },
//   emptyText: {
//     fontSize: 18,
//     fontWeight: '500',
//     color: colors.text,
//     marginTop: 16,
//   },
//   emptySubText: {
//     fontSize: 14,
//     color: colors.gray,
//     marginTop: 8,
//   },
// });
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Image,
  SafeAreaView,
  StatusBar,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/Ionicons';
import { colors } from '../../constants/colors';

// Dummy data for restaurants and items
const ALL_RESTAURANTS = [
  { id: 1, name: 'Pizza Hut', cuisine: 'Pizzas', rating: 4.0, image: 'https://via.placeholder.com/80', deliveryTime: '30-35 mins' },
  { id: 2, name: 'Chinese Wok', cuisine: 'Chinese, Asian', rating: 4.1, image: 'https://via.placeholder.com/80', deliveryTime: '25-30 mins' },
  { id: 3, name: 'UBQ by Barbeque Nation', cuisine: 'Barbeque, Biryani', rating: 3.9, image: 'https://via.placeholder.com/80', deliveryTime: '30-35 mins' },
  { id: 4, name: 'Barbeque Nation', cuisine: 'Barbeque, Biryani, Kebabs', rating: 3.9, image: 'https://via.placeholder.com/80', deliveryTime: '35-40 mins' },
  { id: 5, name: 'McDonalds', cuisine: 'Burgers, Fast Food', rating: 4.2, image: 'https://via.placeholder.com/80', deliveryTime: '20-25 mins' },
  { id: 6, name: 'Burger King', cuisine: 'Burgers', rating: 4.3, image: 'https://via.placeholder.com/80', deliveryTime: '25-30 mins' },
  { id: 7, name: 'KFC', cuisine: 'Fried Chicken', rating: 4.1, image: 'https://via.placeholder.com/80', deliveryTime: '25-30 mins' },
  { id: 8, name: 'Domino\'s Pizza', cuisine: 'Pizzas', rating: 4.4, image: 'https://via.placeholder.com/80', deliveryTime: '30-35 mins' },
  { id: 9, name: 'Subway', cuisine: 'Sandwiches, Healthy Food', rating: 4.0, image: 'https://via.placeholder.com/80', deliveryTime: '15-20 mins' },
  { id: 10, name: 'Taco Bell', cuisine: 'Mexican', rating: 4.1, image: 'https://via.placeholder.com/80', deliveryTime: '20-25 mins' },
];

const POPULAR_CATEGORIES = [
  { id: 1, name: 'Pizza', icon: '🍕' },
  { id: 2, name: 'Biryani', icon: '🍚' },
  { id: 3, name: 'Burger', icon: '🍔' },
  { id: 4, name: 'Dosa', icon: '🥞' },
  { id: 5, name: 'North Indian', icon: '🍛' },
  { id: 6, name: 'Chinese', icon: '🥢' },
];

interface SearchScreenProps {
  navigation: any;
}

const SearchScreen: React.FC<SearchScreenProps> = ({ navigation }) => {
  const [searchText, setSearchText] = useState<string>('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [isSearching, setIsSearching] = useState<boolean>(false);

  // Load recent searches on mount
  useEffect(() => {
    loadRecentSearches();
  }, []);

  // Load recent searches from AsyncStorage
  const loadRecentSearches = async () => {
    try {
      const saved = await AsyncStorage.getItem('recentSearches');
      if (saved) {
        setRecentSearches(JSON.parse(saved));
      }
    } catch (error) {
      console.error('Failed to load recent searches:', error);
    }
  };

  // Save recent searches to AsyncStorage
  const saveRecentSearches = async (searches: string[]) => {
    try {
      await AsyncStorage.setItem('recentSearches', JSON.stringify(searches));
    } catch (error) {
      console.error('Failed to save recent searches:', error);
    }
  };

  // Handle search
  const handleSearch = (text: string) => {
    setSearchText(text);
    setIsSearching(text.length > 0);

    if (text.trim()) {
      // Filter restaurants based on search text
      const results = ALL_RESTAURANTS.filter(
        (item) =>
          item.name.toLowerCase().includes(text.toLowerCase()) ||
          item.cuisine.toLowerCase().includes(text.toLowerCase())
      );
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  };

  // Save search to recent
  const saveSearch = (term: string) => {
    if (!term.trim()) return;
    
    let updatedSearches = [term, ...recentSearches.filter(s => s !== term)];
    if (updatedSearches.length > 10) {
      updatedSearches = updatedSearches.slice(0, 10);
    }
    setRecentSearches(updatedSearches);
    saveRecentSearches(updatedSearches);
  };

  // Handle search submit
  const handleSearchSubmit = () => {
    if (searchText.trim()) {
      saveSearch(searchText.trim());
      // Navigate to search results or show results
      setIsSearching(true);
    }
  };

  // Clear search
  const clearSearch = () => {
    setSearchText('');
    setSearchResults([]);
    setIsSearching(false);
  };

  // Clear a single recent search
  const clearRecentSearch = async (term: string) => {
    const updated = recentSearches.filter(s => s !== term);
    setRecentSearches(updated);
    await saveRecentSearches(updated);
  };

  // Clear all recent searches
  const clearAllRecentSearches = async () => {
    Alert.alert(
      'Clear Recent Searches',
      'Are you sure you want to clear all recent searches?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear All',
          style: 'destructive',
          onPress: async () => {
            setRecentSearches([]);
            await saveRecentSearches([]);
          },
        },
      ]
    );
  };

  // Handle category click
  const handleCategoryClick = (category: string) => {
    setSearchText(category);
    saveSearch(category);
    const results = ALL_RESTAURANTS.filter(
      (item) =>
        item.cuisine.toLowerCase().includes(category.toLowerCase()) ||
        item.name.toLowerCase().includes(category.toLowerCase())
    );
    setSearchResults(results);
    setIsSearching(true);
  };

  // Handle recent search click
  const handleRecentSearchClick = (term: string) => {
    setSearchText(term);
    saveSearch(term);
    const results = ALL_RESTAURANTS.filter(
      (item) =>
        item.name.toLowerCase().includes(term.toLowerCase()) ||
        item.cuisine.toLowerCase().includes(term.toLowerCase())
    );
    setSearchResults(results);
    setIsSearching(true);
  };

  // Render search result item
  const renderSearchResult = ({ item }: { item: any }) => (
    <TouchableOpacity
      style={styles.resultItem}
      onPress={() => {
        saveSearch(item.name);
        navigation.navigate('RestaurantDetail', { restaurant: item });
      }}
    >
      <Image source={{ uri: item.image }} style={styles.resultImage} />
      <View style={styles.resultInfo}>
        <Text style={styles.resultName}>{item.name}</Text>
        <Text style={styles.resultCuisine}>{item.cuisine}</Text>
        <View style={styles.resultMeta}>
          <Icon name="star" size={14} color="#ffc107" />
          <Text style={styles.resultRating}>{item.rating}</Text>
          <Text style={styles.resultTime}>• {item.deliveryTime}</Text>
        </View>
      </View>
      <Icon name="chevron-forward" size={20} color="#ccc" />
    </TouchableOpacity>
  );

  // Render recent search item
  const renderRecentSearch = ({ item }: { item: string }) => (
    <TouchableOpacity
      style={styles.recentItem}
      onPress={() => handleRecentSearchClick(item)}
    >
      <View style={styles.recentItemLeft}>
        <Icon name="time-outline" size={20} color="#7e808c" />
        <Text style={styles.recentItemText}>{item}</Text>
      </View>
      <TouchableOpacity onPress={() => clearRecentSearch(item)}>
        <Icon name="close-circle" size={20} color="#ccc" />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  // Render popular category
  const renderCategory = ({ item }: { item: any }) => (
    <TouchableOpacity
      style={styles.categoryChip}
      onPress={() => handleCategoryClick(item.name)}
    >
      <Text style={styles.categoryChipText}>{item.icon} {item.name}</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />

      {/* Header with Back Button */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Icon name="arrow-back" size={24} color="#282c3f" />
        </TouchableOpacity>
        <View style={styles.searchContainer}>
          <Icon name="search" size={20} color="#7e808c" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search for restaurant, item or more"
            value={searchText}
            onChangeText={handleSearch}
            onSubmitEditing={handleSearchSubmit}
            autoFocus
            returnKeyType="search"
          />
          {searchText.length > 0 && (
            <TouchableOpacity onPress={clearSearch}>
              <Icon name="close-circle" size={20} color="#7e808c" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Content */}
      {isSearching ? (
        // Search Results
        <FlatList
          data={searchResults}
          renderItem={renderSearchResult}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.resultsList}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Icon name="search-outline" size={60} color="#ccc" />
              <Text style={styles.emptyText}>No results found</Text>
              <Text style={styles.emptySubText}>
                Try searching for something else
              </Text>
              {searchText.length > 0 && (
                <Text style={styles.emptySearchText}>
                  "{searchText}"
                </Text>
              )}
            </View>
          }
          ListHeaderComponent={
            searchResults.length > 0 ? (
              <Text style={styles.resultsCount}>
                {searchResults.length} result{searchResults.length > 1 ? 's' : ''} found
              </Text>
            ) : null
          }
        />
      ) : (
        // Default View
        <FlatList
          data={[]}
          renderItem={() => null}
          ListHeaderComponent={
            <View style={styles.content}>
              {/* Popular Categories */}
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Popular Categories</Text>
                <FlatList
                  data={POPULAR_CATEGORIES}
                  renderItem={renderCategory}
                  keyExtractor={(item) => item.id.toString()}
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.categoriesList}
                />
              </View>

              {/* Recent Searches */}
              {recentSearches.length > 0 && (
                <View style={styles.section}>
                  <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>Recent Searches</Text>
                    <TouchableOpacity onPress={clearAllRecentSearches}>
                      <Text style={styles.clearAllText}>Clear All</Text>
                    </TouchableOpacity>
                  </View>
                  <FlatList
                    data={recentSearches}
                    renderItem={renderRecentSearch}
                    keyExtractor={(item, index) => index.toString()}
                    showsVerticalScrollIndicator={false}
                  />
                </View>
              )}

              {/* Popular Items */}
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Popular Restaurants</Text>
                {ALL_RESTAURANTS.slice(0, 5).map((item) => (
                  <TouchableOpacity
                    key={item.id}
                    style={styles.popularItem}
                    onPress={() => {
                      saveSearch(item.name);
                      navigation.navigate('RestaurantDetail', { restaurant: item });
                    }}
                  >
                    <View style={styles.popularItemLeft}>
                      <View style={styles.popularItemImage} />
                      <View style={styles.popularItemInfo}>
                        <Text style={styles.popularItemName}>{item.name}</Text>
                        <Text style={styles.popularItemCuisine}>{item.cuisine}</Text>
                      </View>
                    </View>
                    <Icon name="chevron-forward" size={20} color="#ccc" />
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          }
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f5',
  },
  backButton: {
    marginRight: 12,
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f0f0f5',
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 44,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: '#282c3f',
    padding: 0,
  },
  content: {
    paddingHorizontal: 16,
    paddingBottom: 80,
  },
  section: {
    marginTop: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#282c3f',
    marginBottom: 12,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  clearAllText: {
    fontSize: 13,
    color: '#fc8019',
    fontWeight: '500',
  },
  categoriesList: {
    paddingVertical: 4,
  },
  categoryChip: {
    backgroundColor: '#f0f0f5',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    marginRight: 10,
  },
  categoryChipText: {
    fontSize: 14,
    color: '#282c3f',
  },
  recentItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f5',
  },
  recentItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  recentItemText: {
    fontSize: 14,
    color: '#282c3f',
    marginLeft: 12,
  },
  resultsList: {
    padding: 16,
    paddingBottom: 80,
  },
  resultsCount: {
    fontSize: 14,
    color: '#7e808c',
    marginBottom: 12,
  },
  resultItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    padding: 12,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#f0f0f5',
  },
  resultImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    backgroundColor: '#f0f0f5',
  },
  resultInfo: {
    flex: 1,
    marginLeft: 12,
  },
  resultName: {
    fontSize: 15,
    fontWeight: '600',
    color: '#282c3f',
  },
  resultCuisine: {
    fontSize: 13,
    color: '#7e808c',
    marginTop: 2,
  },
  resultMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  resultRating: {
    fontSize: 12,
    color: '#282c3f',
    marginLeft: 4,
  },
  resultTime: {
    fontSize: 12,
    color: '#7e808c',
    marginLeft: 8,
  },
  popularItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f5',
  },
  popularItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  popularItemImage: {
    width: 50,
    height: 50,
    borderRadius: 8,
    backgroundColor: '#f0f0f5',
    marginRight: 12,
  },
  popularItemInfo: {
    flex: 1,
  },
  popularItemName: {
    fontSize: 14,
    fontWeight: '500',
    color: '#282c3f',
  },
  popularItemCuisine: {
    fontSize: 12,
    color: '#7e808c',
    marginTop: 2,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '500',
    color: '#282c3f',
    marginTop: 16,
  },
  emptySubText: {
    fontSize: 14,
    color: '#7e808c',
    marginTop: 8,
  },
  emptySearchText: {
    fontSize: 16,
    color: '#fc8019',
    fontWeight: '500',
    marginTop: 8,
  },
});

export default SearchScreen;