import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { colors } from '../../constants/colors';
import OrderCard from '../../components/orders/OrderCard';
import { Order } from '../../types';

export default function OrdersScreen({ navigation }: any) {
  const [activeTab, setActiveTab] = useState<string>('current');

  const tabs: { id: string; label: string }[] = [
    { id: 'current', label: 'Current' },
    { id: 'past', label: 'Past' },
    { id: 'cancelled', label: 'Cancelled' },
  ];

  const orders: Order[] = [
    {
      id: '1',
      restaurantId: '1',
      restaurantName: 'Pizza Hut',
      items: [],
      total: 461,
      status: 'Delivered',
      deliveryAddress: { id: '1', type: 'Home', address: '', city: '', state: '', pincode: '', isDefault: true },
      paymentMethod: 'Card',
      createdAt: '2026-07-29T18:26:00',
    },
    {
      id: '2',
      restaurantId: '2',
      restaurantName: 'Burger Craft',
      items: [],
      total: 810,
      status: 'On the way',
      deliveryAddress: { id: '1', type: 'Home', address: '', city: '', state: '', pincode: '', isDefault: true },
      paymentMethod: 'UPI',
      createdAt: '2026-07-29T14:30:00',
    },
  ];

  const getStatusColor = (status: Order['status']): string => {
    switch (status) {
      case 'Delivered': return colors.success;
      case 'On the way': return colors.info;
      case 'Preparing': return colors.warning;
      case 'Cancelled': return colors.danger;
      default: return colors.gray;
    }
  };

  const renderOrder = ({ item }: { item: Order }) => (
    <OrderCard
      order={item}
      onPress={() => navigation.navigate('OrderTracking', { orderId: item.id })}
      onReorder={() => {
        navigation.navigate('RestaurantDetail', { restaurant: { id: item.restaurantId, name: item.restaurantName } });
      }}
    />
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>My Orders</Text>
      </View>

      {/* Tabs */}
      <View style={styles.tabsContainer}>
        {tabs.map((tab) => (
          <TouchableOpacity
            key={tab.id}
            style={[styles.tab, activeTab === tab.id && styles.activeTab]}
            onPress={() => setActiveTab(tab.id)}
          >
            <Text style={[styles.tabText, activeTab === tab.id && styles.activeTabText]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Orders List */}
      <FlatList
        data={orders}
        renderItem={renderOrder}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.ordersList}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Icon name="clipboard-outline" size={60} color={colors.gray} />
            <Text style={styles.emptyText}>No orders yet</Text>
            <Text style={styles.emptySubText}>Your orders will appear here</Text>
            <TouchableOpacity
              style={styles.browseButton}
              onPress={() => navigation.navigate('Home')}
            >
              <Text style={styles.browseButtonText}>Browse Restaurants</Text>
            </TouchableOpacity>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  header: {
    padding: 16,
    paddingTop: 40,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.text,
  },
  tabsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  tab: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    borderRadius: 20,
  },
  activeTab: {
    backgroundColor: colors.primary,
  },
  tabText: {
    fontSize: 14,
    color: colors.gray,
    fontWeight: '500',
  },
  activeTabText: {
    color: colors.white,
  },
  ordersList: {
    padding: 16,
    paddingBottom: 80,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '500',
    color: colors.text,
    marginTop: 16,
  },
  emptySubText: {
    fontSize: 14,
    color: colors.gray,
    marginTop: 8,
    marginBottom: 24,
  },
  browseButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  browseButtonText: {
    color: colors.white,
    fontWeight: '600',
    fontSize: 16,
  },
});