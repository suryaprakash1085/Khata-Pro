import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Switch,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { colors } from '../../constants/colors';
import { CartContext } from '../../context/CartContext';

export default function CheckoutScreen({ navigation }: any) {
  const { cartItems, getTotalPrice, getTotalItems } = useContext(CartContext);
  const [noContactDelivery, setNoContactDelivery] = useState<boolean>(false);

  const deliveryFee: number = 47;
  const taxesAndCharges: number = 44.7;
  const total: number = getTotalPrice() + deliveryFee + taxesAndCharges;

  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Icon name="arrow-back" size={24} color={colors.text} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Secure Checkout</Text>
          <View style={{ width: 24 }} />
        </View>

        {/* Account Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account</Text>
          <Text style={styles.sectionSubtitle}>
            To place your order now, log in to your existing account or sign up.
          </Text>
          <View style={styles.accountButtons}>
            <TouchableOpacity style={styles.accountButton}>
              <Text style={styles.accountButtonText}>LOG IN</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.accountButton, styles.signupButton]}>
              <Text style={[styles.accountButtonText, styles.signupButtonText]}>
                SIGN UP
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Delivery Address */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Delivery Address</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Address')}>
              <Text style={styles.changeText}>Change</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.addressCard}>
            <Icon name="location-outline" size={20} color={colors.primary} />
            <View style={styles.addressInfo}>
              <Text style={styles.addressType}>Home</Text>
              <Text style={styles.addressText}>
                A-7, Sushil Apartment, Ramdas Colony, Nashik, Maharashtra 422005
              </Text>
            </View>
          </View>
        </View>

        {/* Order Details */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Order Details</Text>
          <View style={styles.orderSummary}>
            {cartItems.map((item) => (
              <View key={`${item.id}-${item.restaurantId}`} style={styles.orderItem}>
                <Text style={styles.orderItemName}>
                  {item.name} × {item.quantity}
                </Text>
                <Text style={styles.orderItemPrice}>₹{item.price * item.quantity}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* No Contact Delivery */}
        <View style={styles.section}>
          <View style={styles.noContactContainer}>
            <View>
              <Text style={styles.noContactTitle}>Opt in for No-contact Delivery</Text>
              <Text style={styles.noContactSubtitle}>
                Unwell, or avoiding contact? Please select no-contact delivery.
              </Text>
            </View>
            <Switch
              value={noContactDelivery}
              onValueChange={setNoContactDelivery}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor={colors.white}
            />
          </View>
        </View>

        {/* Bill Details */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Bill Details</Text>
          <View style={styles.billContainer}>
            <View style={styles.billRow}>
              <Text style={styles.billLabel}>Item Total</Text>
              <Text style={styles.billValue}>₹{getTotalPrice()}</Text>
            </View>
            <View style={styles.billRow}>
              <Text style={styles.billLabel}>Delivery Partner Fee</Text>
              <Text style={styles.billValue}>₹{deliveryFee}</Text>
            </View>
            <View style={styles.billRow}>
              <Text style={styles.billLabel}>Taxes and Charges</Text>
              <Text style={styles.billValue}>₹{taxesAndCharges}</Text>
            </View>
            <View style={[styles.billRow, styles.totalRow]}>
              <Text style={styles.totalLabel}>TO PAY</Text>
              <Text style={styles.totalValue}>₹{total}</Text>
            </View>
          </View>
        </View>
      </ScrollView>

      {/* Place Order Button */}
      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.placeOrderButton}
          onPress={() => navigation.navigate('OrderTracking')}
        >
          <Text style={styles.placeOrderText}>Place Order • ₹{total}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    paddingTop: 40,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  section: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: colors.textLight,
    marginTop: 4,
  },
  accountButtons: {
    flexDirection: 'row',
    marginTop: 12,
  },
  accountButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 8,
    marginRight: 12,
  },
  accountButtonText: {
    color: colors.white,
    fontWeight: '600',
  },
  signupButton: {
    backgroundColor: colors.lightGray,
  },
  signupButtonText: {
    color: colors.text,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  changeText: {
    color: colors.primary,
    fontSize: 14,
    fontWeight: '500',
  },
  addressCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginTop: 12,
    padding: 12,
    backgroundColor: colors.lightGray,
    borderRadius: 8,
  },
  addressInfo: {
    marginLeft: 12,
    flex: 1,
  },
  addressType: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
  },
  addressText: {
    fontSize: 13,
    color: colors.textLight,
    marginTop: 2,
  },
  orderSummary: {
    marginTop: 12,
  },
  orderItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },
  orderItemName: {
    fontSize: 14,
    color: colors.text,
  },
  orderItemPrice: {
    fontSize: 14,
    color: colors.text,
    fontWeight: '500',
  },
  noContactContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  noContactTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
  },
  noContactSubtitle: {
    fontSize: 12,
    color: colors.textLight,
    marginTop: 4,
  },
  billContainer: {
    marginTop: 12,
  },
  billRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },
  billLabel: {
    fontSize: 14,
    color: colors.textLight,
  },
  billValue: {
    fontSize: 14,
    color: colors.text,
  },
  totalRow: {
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: 12,
    marginTop: 4,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  totalValue: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.primary,
  },
  footer: {
    padding: 16,
    backgroundColor: colors.white,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  placeOrderButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeOrderText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
});