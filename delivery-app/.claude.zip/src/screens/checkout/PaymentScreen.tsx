import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  Alert,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { colors } from '../../constants/colors';

interface PaymentScreenProps {
  navigation: any;
  route: any;
}

export default function PaymentScreen({ route, navigation }: PaymentScreenProps) {
  const { totalAmount } = route.params || { totalAmount: 461 };
  const [selectedMethod, setSelectedMethod] = useState<string>('card');
  const [cardNumber, setCardNumber] = useState<string>('');
  const [expiryDate, setExpiryDate] = useState<string>('');
  const [cvv, setCvv] = useState<string>('');
  const [cardHolder, setCardHolder] = useState<string>('');

  const paymentMethods: { id: string; name: string; icon: string }[] = [
    { id: 'card', name: 'Credit/Debit Card', icon: 'card-outline' },
    { id: 'upi', name: 'UPI', icon: 'phone-portrait-outline' },
    { id: 'netbanking', name: 'Net Banking', icon: 'business-outline' },
    { id: 'wallet', name: 'Wallet', icon: 'wallet-outline' },
    { id: 'cash', name: 'Cash on Delivery', icon: 'cash-outline' },
  ];

  const handlePayment = (): void => {
    if (selectedMethod === 'card') {
      if (!cardNumber || !expiryDate || !cvv || !cardHolder) {
        Alert.alert('Error', 'Please fill all card details');
        return;
      }
      if (cardNumber.replace(/\s/g, '').length !== 16) {
        Alert.alert('Error', 'Please enter a valid 16-digit card number');
        return;
      }
    }

    Alert.alert(
      'Payment Successful',
      `Your payment of ₹${totalAmount} has been processed successfully.`,
      [
        {
          text: 'OK',
          onPress: () => navigation.navigate('OrderTracking'),
        },
      ]
    );
  };

  const formatCardNumber = (text: string): string => {
    const cleaned = text.replace(/\s/g, '');
    const matches = cleaned.match(/.{1,4}/g);
    if (matches) {
      return matches.join(' ');
    }
    return text;
  };

  const formatExpiryDate = (text: string): string => {
    const cleaned = text.replace(/\D/g, '');
    if (cleaned.length >= 2) {
      return `${cleaned.slice(0, 2)}/${cleaned.slice(2, 4)}`;
    }
    return text;
  };

  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Icon name="arrow-back" size={24} color={colors.text} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Payment</Text>
          <View style={{ width: 24 }} />
        </View>

        <View style={styles.amountContainer}>
          <Text style={styles.amountLabel}>Amount to Pay</Text>
          <Text style={styles.amountValue}>₹{totalAmount}</Text>
        </View>

        <View style={styles.methodsContainer}>
          <Text style={styles.sectionTitle}>Payment Methods</Text>
          {paymentMethods.map((method) => (
            <TouchableOpacity
              key={method.id}
              style={[
                styles.methodItem,
                selectedMethod === method.id && styles.selectedMethod,
              ]}
              onPress={() => setSelectedMethod(method.id)}
            >
              <View style={styles.methodLeft}>
                <Icon name={method.icon} size={24} color={selectedMethod === method.id ? colors.primary : colors.text} />
                <Text style={[
                  styles.methodName,
                  selectedMethod === method.id && styles.selectedMethodText,
                ]}>
                  {method.name}
                </Text>
              </View>
              {selectedMethod === method.id && (
                <Icon name="checkmark-circle" size={24} color={colors.primary} />
              )}
            </TouchableOpacity>
          ))}
        </View>

        {selectedMethod === 'card' && (
          <View style={styles.cardContainer}>
            <Text style={styles.sectionTitle}>Card Details</Text>
            
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Card Number</Text>
              <TextInput
                style={styles.input}
                placeholder="1234 5678 9012 3456"
                value={cardNumber}
                onChangeText={(text) => setCardNumber(formatCardNumber(text))}
                keyboardType="numeric"
                maxLength={19}
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Card Holder Name</Text>
              <TextInput
                style={styles.input}
                placeholder="John Doe"
                value={cardHolder}
                onChangeText={setCardHolder}
              />
            </View>

            <View style={styles.rowInputs}>
              <View style={[styles.inputContainer, styles.halfInput]}>
                <Text style={styles.inputLabel}>Expiry Date</Text>
                <TextInput
                  style={styles.input}
                  placeholder="MM/YY"
                  value={expiryDate}
                  onChangeText={(text) => setExpiryDate(formatExpiryDate(text))}
                  keyboardType="numeric"
                  maxLength={5}
                />
              </View>
              <View style={[styles.inputContainer, styles.halfInput]}>
                <Text style={styles.inputLabel}>CVV</Text>
                <TextInput
                  style={styles.input}
                  placeholder="123"
                  value={cvv}
                  onChangeText={setCvv}
                  keyboardType="numeric"
                  maxLength={4}
                  secureTextEntry
                />
              </View>
            </View>

            <View style={styles.secureContainer}>
              <Icon name="lock-closed-outline" size={16} color={colors.success} />
              <Text style={styles.secureText}>Your payment is secure</Text>
            </View>
          </View>
        )}

        {selectedMethod === 'upi' && (
          <View style={styles.cardContainer}>
            <Text style={styles.sectionTitle}>UPI Details</Text>
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>UPI ID</Text>
              <TextInput
                style={styles.input}
                placeholder="example@upi"
              />
            </View>
            <View style={styles.upiApps}>
              <Text style={styles.inputLabel}>Pay with</Text>
              <View style={styles.upiAppList}>
                {['Google Pay', 'PhonePe', 'Paytm', 'Amazon Pay'].map((app) => (
                  <TouchableOpacity key={app} style={styles.upiAppButton}>
                    <Text style={styles.upiAppText}>{app}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </View>
        )}
      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity style={styles.payButton} onPress={handlePayment}>
          <Text style={styles.payButtonText}>
            Pay ₹{totalAmount}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    paddingTop: 40,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  amountContainer: {
    backgroundColor: colors.primary,
    padding: 20,
    margin: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  amountLabel: {
    fontSize: 14,
    color: colors.white,
    opacity: 0.8,
  },
  amountValue: {
    fontSize: 28,
    fontWeight: '700',
    color: colors.white,
    marginTop: 4,
  },
  methodsContainer: {
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  methodItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 14,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 10,
    marginBottom: 8,
  },
  selectedMethod: {
    borderColor: colors.primary,
    backgroundColor: '#fff5ec',
  },
  methodLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  methodName: {
    fontSize: 14,
    color: colors.text,
    marginLeft: 12,
  },
  selectedMethodText: {
    color: colors.primary,
    fontWeight: '500',
  },
  cardContainer: {
    padding: 16,
    margin: 16,
    backgroundColor: colors.lightGray,
    borderRadius: 12,
  },
  inputContainer: {
    marginBottom: 12,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
    marginBottom: 4,
  },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    color: colors.text,
    backgroundColor: colors.white,
  },
  rowInputs: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  halfInput: {
    flex: 1,
    marginRight: 8,
  },
  secureContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  secureText: {
    fontSize: 12,
    color: colors.success,
    marginLeft: 4,
  },
  upiApps: {
    marginTop: 8,
  },
  upiAppList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 8,
  },
  upiAppButton: {
    backgroundColor: colors.white,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    marginRight: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  upiAppText: {
    fontSize: 12,
    color: colors.text,
  },
  footer: {
    padding: 16,
    backgroundColor: colors.white,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  payButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  payButtonText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
});