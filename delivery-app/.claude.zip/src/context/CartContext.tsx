import React, { createContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { CartItem, Restaurant } from '../types';

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (item: CartItem, restaurant: Restaurant) => void;
  removeFromCart: (itemId: string, restaurantId: string) => void;
  updateQuantity: (itemId: string, restaurantId: string, quantity: number) => void;
  clearCart: () => void;
  getTotalPrice: () => number;
  getTotalItems: () => number;
}

export const CartContext = createContext<CartContextType>({
  cartItems: [],
  addToCart: () => {},
  removeFromCart: () => {},
  updateQuantity: () => {},
  clearCart: () => {},
  getTotalPrice: () => 0,
  getTotalItems: () => 0,
});

interface CartProviderProps {
  children: ReactNode;
}

// export function CartProvider({ children }: CartProviderProps): JSX.Element {
export function CartProvider({ children }: CartProviderProps) {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  useEffect(() => {
    loadCart();
  }, []);

  const loadCart = async (): Promise<void> => {
    try {
      const savedCart = await AsyncStorage.getItem('cartItems');
      if (savedCart) {
        setCartItems(JSON.parse(savedCart));
      }
    } catch (error) {
      console.error('Failed to load cart:', error);
    }
  };

  const saveCart = async (items: CartItem[]): Promise<void> => {
    try {
      await AsyncStorage.setItem('cartItems', JSON.stringify(items));
    } catch (error) {
      console.error('Failed to save cart:', error);
    }
  };

  const addToCart = (item: CartItem, restaurant: Restaurant): void => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(i => i.id === item.id && i.restaurantId === restaurant.id);
      let newItems: CartItem[];
      if (existingItem) {
        newItems = prevItems.map(i =>
          i.id === item.id && i.restaurantId === restaurant.id 
            ? { ...i, quantity: i.quantity + 1 } 
            : i
        );
      } else {
        newItems = [...prevItems, { 
          ...item, 
          quantity: 1, 
          restaurantId: restaurant.id,
          restaurantName: restaurant.name 
        }];
      }
      saveCart(newItems);
      return newItems;
    });
  };

  const removeFromCart = (itemId: string, restaurantId: string): void => {
    setCartItems(prevItems => {
      const newItems = prevItems.filter(i => 
        !(i.id === itemId && i.restaurantId === restaurantId)
      );
      saveCart(newItems);
      return newItems;
    });
  };

  const updateQuantity = (itemId: string, restaurantId: string, quantity: number): void => {
    setCartItems(prevItems => {
      const newItems = prevItems.map(i =>
        i.id === itemId && i.restaurantId === restaurantId 
          ? { ...i, quantity: Math.max(0, quantity) } 
          : i
      ).filter(i => i.quantity > 0);
      saveCart(newItems);
      return newItems;
    });
  };

  const clearCart = (): void => {
    setCartItems([]);
    saveCart([]);
  };

  const getTotalPrice = (): number => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  const getTotalItems = (): number => {
    return cartItems.reduce((total, item) => total + item.quantity, 0);
  };

  return (
    <CartContext.Provider value={{
      cartItems,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      getTotalPrice,
      getTotalItems,
      
    }}>
      {children}
    </CartContext.Provider>
  );
}
