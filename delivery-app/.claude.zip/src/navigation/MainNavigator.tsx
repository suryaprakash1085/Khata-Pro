import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Restaurant } from '../types';
import TabNavigator from './TabNavigator';
import RestaurantDetailScreen from '../screens/restaurant/RestaurantDetailScreen';
import CheckoutScreen from '../screens/checkout/CheckoutScreen';
import OrderTrackingScreen from '../screens/order/OrderTrackingScreen';
import FoodDetailScreen from '../screens/restaurant/FoodDetailScreen';

export type MainStackParamList = {
  Tabs: undefined;
  RestaurantDetail: { restaurant: Restaurant };
  FoodDetail: { item: any; restaurant: Restaurant };
  Checkout: undefined;
  OrderTracking: { orderId?: string };
};

const Stack = createNativeStackNavigator<MainStackParamList>();

export default function MainNavigator(){
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Tabs" component={TabNavigator} />
      <Stack.Screen name="RestaurantDetail" component={RestaurantDetailScreen} />
      <Stack.Screen name="FoodDetail" component={FoodDetailScreen} />
      <Stack.Screen name="Checkout" component={CheckoutScreen} />
      <Stack.Screen name="OrderTracking" component={OrderTrackingScreen} />
    </Stack.Navigator>
  );
}