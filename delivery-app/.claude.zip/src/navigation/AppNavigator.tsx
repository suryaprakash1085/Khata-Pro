// // import React, { useContext } from 'react';
// // import { NavigationContainer } from '@react-navigation/native';
// // import { AuthContext } from '../context/AuthContext';
// // import AuthNavigator from './AuthNavigator';
// // import MainNavigator from './MainNavigator';

// // export default function AppNavigator() {
// //   const { isAuthenticated } = useContext(AuthContext);

// //   return (
// //     <NavigationContainer>
// //       {isAuthenticated ? <MainNavigator /> : <AuthNavigator />}
// //     </NavigationContainer>
// //   );
// // }
// import React, { useContext } from 'react';
// import { NavigationContainer, LinkingOptions } from '@react-navigation/native';
// import { AuthContext } from '../context/AuthContext';
// import AuthNavigator from './AuthNavigator';
// import MainNavigator from './MainNavigator';

// const linking: LinkingOptions<any> = {
//   prefixes: [],
//   config: {
//     screens: {
//       // Auth stack routes
//       Login: 'login',
//       Signup: 'signup',
//       ForgotPassword: 'forgot-password',

//       // Main stack routes
//       Tabs: {
//         screens: {
//           Home: 'home',
//           Search: 'search',
//           Cart: 'cart',
//           Orders: 'orders',
//           Profile: 'profile',
//         },
//       },
//       RestaurantDetail: 'restaurant/:restaurant',
//       FoodDetail: 'food/:item',
//       Checkout: 'checkout',
//       OrderTracking: 'order-tracking/:orderId',
//     },
//   },
// };

// export default function AppNavigator() {
//   const { isAuthenticated } = useContext(AuthContext);

//   return (
//     <NavigationContainer linking={linking}>
//       {isAuthenticated ? <MainNavigator /> : <AuthNavigator />}
//     </NavigationContainer>
//   );
// }
import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
// import LandingScreen from '../screens/LandingScreen';
import LoginScreen from '../screens/auth/LoginScreen';
import SignupScreen from '../screens/auth/SignupScreen';
import HomeScreen from '../screens/main/HomeScreen';
import SearchScreen from '../screens/main/SearchScreen';
import RestaurantDetailScreen from '../screens/restaurant/RestaurantDetailScreen';
import CartScreen from '../screens/main/CartScreen';
import ProfileScreen from '../screens/main/ProfileScreen';

const Stack = createNativeStackNavigator();

const AppNavigator: React.FC = () => {
  return (
    <Stack.Navigator 
      initialRouteName="Landing"
      screenOptions={{ headerShown: false }}
    >
      {/* <Stack.Screen name="Landing" component={LandingScreen} /> */}
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Signup" component={SignupScreen} />
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="Search" component={SearchScreen} />
      <Stack.Screen name="RestaurantDetail" component={RestaurantDetailScreen} />
      <Stack.Screen name="Cart" component={CartScreen} />
      <Stack.Screen name="Profile" component={ProfileScreen} />
    </Stack.Navigator>
  );
};

export default AppNavigator;